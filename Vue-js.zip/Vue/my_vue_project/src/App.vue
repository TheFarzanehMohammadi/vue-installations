
<template>
  <div class="page">
    <div class="counter-card">

      <span class="tag">VUE.JS COUNTER</span>

      <h1>شمارنده من</h1>
      <p class="subtitle">هر قدم، یک پیشرفت کوچک ✨</p>

      <div class="number">
        {{ count }}
      </div>

      <div class="buttons">
        <button class="minus" @click="decrease">−</button>
        <button class="reset" @click="reset">↻</button>
        <button class="plus" @click="increase">+</button>
      </div>

      <p class="status">
        {{ count === 0 ? 'از صفر شروع کن!' : 'عالی پیش می‌ری 💚' }}
      </p>

      <div class="line"></div>

      <footer>
        Designed by
        <strong>فرزانه محمدی</strong>
      </footer>

    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const count = ref(0)

function increase() {
  count.value++
}

function decrease() {
  count.value--
}

function reset() {
  count.value = 0
}
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Vazirmatn', sans-serif;
}

.page {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #eaf5f0;
  padding: 20px;
  direction: rtl;
}

.counter-card {
  width: 100%;
  max-width: 360px;
  background: #ffffff;
  padding: 40px 30px;
  border-radius: 28px;
  text-align: center;
  box-shadow: 0 15px 50px rgba(38, 100, 75, 0.09);
}

.tag {
  color: #65a88c;
  font-size: 11px;
  letter-spacing: 3px;
  font-weight: 700;
  direction: ltr;
  display: block;
}

h1 {
  color: #244b3b;
  font-size: 27px;
  margin-top: 18px;
}

.subtitle {
  color: #91a99d;
  font-size: 13px;
  margin-top: 8px;
}

.number {
  font-size: 85px;
  font-weight: 800;
  color: #4eaa83;
  margin: 25px 0;
  line-height: 1.3;
}

.buttons {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 15px;
}

button {
  border: none;
  cursor: pointer;
  font-family: inherit;
  transition: 0.2s;
}

button:hover {
  transform: translateY(-4px);
}

.plus, .minus {
  width: 58px;
  height: 58px;
  border-radius: 18px;
  font-size: 30px;
  color: white;
  background: #4eaa83;
}

.minus {
  background: #c9e8d9;
  color: #34785c;
}

.reset {
  width: 45px;
  height: 45px;
  border-radius: 14px;
  font-size: 24px;
  color: #4eaa83;
  background: #edf7f1;
}

.status {
  color: #83a795;
  font-size: 13px;
  margin-top: 25px;
}

.line {
  height: 1px;
  background: #e8f1ec;
  margin: 28px 0 20px;
}

footer {
  color: #9aafa3;
  font-size: 12px;
}

footer strong {
  display: block;
  color: #34785c;
  font-size: 15px;
  margin-top: 7px;
}
</style>
